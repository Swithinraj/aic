from __future__ import annotations

from typing import List, Optional

import rclpy
from rclpy.duration import Duration
from rclpy.node import Node

from aic_control_interfaces.msg import ControllerState, MotionUpdate, TargetMode, TrajectoryGenerationMode
from aic_control_interfaces.srv import ChangeTargetMode
from geometry_msgs.msg import Point, PointStamped, Pose
from nav_msgs.msg import Path
from std_msgs.msg import ColorRGBA
from visualization_msgs.msg import Marker, MarkerArray

from team_policy.planner.cartesian_planner import CartesianPlanner


class RvizClickToMove(Node):
    def __init__(self) -> None:
        super().__init__("rviz_click_to_move")

        self.declare_parameter("command_frame", "base_link")
        self.declare_parameter("position_tolerance", 0.01)
        self.declare_parameter("publish_rate_hz", 20.0)

        self.command_frame = str(self.get_parameter("command_frame").value)
        self.position_tolerance = float(self.get_parameter("position_tolerance").value)
        publish_rate_hz = float(self.get_parameter("publish_rate_hz").value)

        self.planner = CartesianPlanner()
        self.current_tcp_pose: Optional[Pose] = None
        self.active_waypoints: List[Pose] = []
        self.active_waypoint_index = 0
        self.execution_active = False

        self.clicked_point_sub = self.create_subscription(
            PointStamped,
            "/clicked_point",
            self._on_clicked_point,
            10,
        )
        self.controller_state_sub = self.create_subscription(
            ControllerState,
            "/aic_controller/controller_state",
            self._on_controller_state,
            10,
        )

        self.pose_command_pub = self.create_publisher(
            MotionUpdate,
            "/aic_controller/pose_commands",
            10,
        )
        self.target_marker_pub = self.create_publisher(Marker, "/planner/target_marker", 10)
        self.waypoint_markers_pub = self.create_publisher(MarkerArray, "/planner/waypoint_markers", 10)
        self.path_pub = self.create_publisher(Path, "/planner/waypoint_path", 10)

        self.change_mode_client = self.create_client(ChangeTargetMode, "/aic_controller/change_target_mode")
        self.mode_request_sent = False

        self.timer = self.create_timer(1.0 / publish_rate_hz, self._on_timer)

        self.get_logger().info("rviz_click_to_move started. Click a point in RViz using Publish Point.")
        self.get_logger().info("Set RViz Fixed Frame to base_link before clicking.")

    def _on_controller_state(self, msg: ControllerState) -> None:
        self.current_tcp_pose = msg.tcp_pose
        if not self.mode_request_sent:
            self._request_cartesian_mode()

    def _request_cartesian_mode(self) -> None:
        if not self.change_mode_client.wait_for_service(timeout_sec=0.1):
            return

        request = ChangeTargetMode.Request()
        request.target_mode.mode = TargetMode.MODE_CARTESIAN
        self.change_mode_client.call_async(request)
        self.mode_request_sent = True
        self.get_logger().info("Requested Cartesian target mode.")

    def _on_clicked_point(self, msg: PointStamped) -> None:
        if self.current_tcp_pose is None:
            self.get_logger().warn("No controller state received yet. Ignoring clicked point.")
            return

        if msg.header.frame_id not in ("", self.command_frame, "base"):
            self.get_logger().warn(
                f"Clicked point frame '{msg.header.frame_id}' is unexpected. "
                f"Set RViz Fixed Frame to {self.command_frame}."
            )

        target_pose = Pose()
        target_pose.position.x = msg.point.x
        target_pose.position.y = msg.point.y
        target_pose.position.z = msg.point.z
        target_pose.orientation = self.current_tcp_pose.orientation

        self.active_waypoints = self.planner.plan_from_current_pose(
            current_pose=self.current_tcp_pose,
            target_pose=target_pose,
        )
        self.active_waypoint_index = 0
        self.execution_active = len(self.active_waypoints) > 0

        self._publish_target_marker(msg.point)
        self._publish_waypoint_visuals(self.active_waypoints)

        self.get_logger().info(
            f"Received target point ({msg.point.x:.3f}, {msg.point.y:.3f}, {msg.point.z:.3f}). "
            f"Generated {len(self.active_waypoints)} waypoints."
        )

    def _on_timer(self) -> None:
        if not self.execution_active:
            return
        if self.current_tcp_pose is None:
            return
        if self.active_waypoint_index >= len(self.active_waypoints):
            self.execution_active = False
            self.get_logger().info("Waypoint execution complete.")
            return

        waypoint = self.active_waypoints[self.active_waypoint_index]
        self._publish_motion_command(waypoint)

        if self._position_distance(self.current_tcp_pose, waypoint) <= self.position_tolerance:
            self.active_waypoint_index += 1
            if self.active_waypoint_index < len(self.active_waypoints):
                self.get_logger().info(
                    f"Advancing to waypoint {self.active_waypoint_index + 1}/{len(self.active_waypoints)}"
                )
            else:
                self.execution_active = False
                self.get_logger().info("Final waypoint reached.")

    def _publish_motion_command(self, pose: Pose) -> None:
        msg = MotionUpdate()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.command_frame
        msg.pose = pose
        msg.trajectory_generation_mode.mode = TrajectoryGenerationMode.MODE_POSITION
        self.pose_command_pub.publish(msg)

    def _publish_target_marker(self, point: Point) -> None:
        marker = Marker()
        marker.header.frame_id = self.command_frame
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "planner_target"
        marker.id = 0
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD
        marker.pose.position.x = point.x
        marker.pose.position.y = point.y
        marker.pose.position.z = point.z
        marker.pose.orientation.w = 1.0
        marker.scale.x = 0.03
        marker.scale.y = 0.03
        marker.scale.z = 0.03
        marker.color = ColorRGBA(r=1.0, g=0.0, b=0.0, a=1.0)
        self.target_marker_pub.publish(marker)

    def _publish_waypoint_visuals(self, waypoints: List[Pose]) -> None:
        marker_array = MarkerArray()

        delete_marker = Marker()
        delete_marker.action = Marker.DELETEALL
        marker_array.markers.append(delete_marker)

        for index, waypoint in enumerate(waypoints):
            marker = Marker()
            marker.header.frame_id = self.command_frame
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = "planner_waypoints"
            marker.id = index
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose = waypoint
            marker.scale.x = 0.02
            marker.scale.y = 0.02
            marker.scale.z = 0.02
            marker.color = ColorRGBA(r=0.0, g=1.0, b=0.0, a=1.0)
            marker_array.markers.append(marker)

        self.waypoint_markers_pub.publish(marker_array)

        path = Path()
        path.header.frame_id = self.command_frame
        path.header.stamp = self.get_clock().now().to_msg()
        for waypoint in waypoints:
            pose_stamped = self._pose_to_stamped(waypoint)
            path.poses.append(pose_stamped)
        self.path_pub.publish(path)

    def _pose_to_stamped(self, pose: Pose):
        from geometry_msgs.msg import PoseStamped

        pose_stamped = PoseStamped()
        pose_stamped.header.frame_id = self.command_frame
        pose_stamped.header.stamp = self.get_clock().now().to_msg()
        pose_stamped.pose = pose
        return pose_stamped

    def _position_distance(self, pose_a: Pose, pose_b: Pose) -> float:
        dx = pose_a.position.x - pose_b.position.x
        dy = pose_a.position.y - pose_b.position.y
        dz = pose_a.position.z - pose_b.position.z
        return (dx * dx + dy * dy + dz * dz) ** 0.5


def main() -> None:
    rclpy.init()
    node = RvizClickToMove()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
