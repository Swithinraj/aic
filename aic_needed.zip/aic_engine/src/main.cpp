/*
 * Copyright (C) 2025 Intrinsic Innovation LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <cstdlib>

#include "aic_engine.hpp"
#include "rclcpp/executor.hpp"

//==============================================================================
int main(int argc, char** argv) {
  rclcpp::init(argc, argv);

  auto engine = std::make_shared<aic::Engine>();
  aic::EngineState final_state = engine->start();

  rclcpp::shutdown();
  return (final_state == aic::EngineState::Completed) ? EXIT_SUCCESS
                                                      : EXIT_FAILURE;
}